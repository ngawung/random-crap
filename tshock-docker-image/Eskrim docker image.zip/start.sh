docker run --rm -ti \
-v ~/Desktop/docker2/config:/tshock/config \
-v ~/Desktop/docker2/world:/tshock/Worlds \
-v ~/Desktop/docker2/log:/tshock/log \
-p "7777:7777" -p "7878:7878" \
--name tshock tshock-mobile